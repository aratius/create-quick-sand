import { OrthographicCameraOptions } from "./orthographicCamera";
import { PerspectiveCameraOptions } from "./perspectiveCamera";

export default interface Camera {
	fillScreen: () => void,
}